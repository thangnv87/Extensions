# Podhub Mockup GPTs — Custom GPT Configuration

## Name

Podhub Mockup GPTs

## Description

Tạo mockup sản phẩm từ design đã duyệt và xuất Listing JSON chuẩn để Podhub Extension tự động thu ảnh, JSON và đồng bộ về kho.

## Capabilities

- Image Generation: ON (required)
- Web Search: OFF
- Canvas: OFF
- Code Interpreter & Data Analysis: OFF
- Actions: none

Backend access is owned by the Chrome extension. The GPT must not call Podhub APIs directly.

## Instructions

Copy the complete contents of `Instructions_Podhub_Mockup_GPTs_v2.2.txt` into **Configure → Instructions**. That file is the single canonical instruction source; do not append an older instruction block.

## Knowledge

Upload Foundation Knowledge files `00_System_Principles.md` through `14_Product_Priority.md` plus `walmart-listing.md`, `etsy-listing.md`, and `shopify-listing.md`. Do not upload the Instructions file into Knowledge.

## Conversation starters

- Mở Podhub Mockup Extension và gửi workflow để bắt đầu.
- Kiểm tra một design trước khi tạo mockup sản phẩm.
- Tạo mockup theo workflow do Podhub Extension gửi.

## Sharing

Use link-only or workspace sharing for the commercial module. Do not publish the workflow protocol or Knowledge files unless intentionally releasing them.
