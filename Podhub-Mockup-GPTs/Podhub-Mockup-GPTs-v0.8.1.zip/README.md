# Podhub Mockup GPTs

Chrome Extension Manifest V3 điều phối workflow thương mại theo Queue.

## Workflow v0.8

1. Nhận một hoặc nhiều Raw Design từ Podhub hoặc Upload thủ công.
2. Tạo một backend job cho mỗi design và hiển thị thành card trong Queue.
3. Mở một cuộc chat Custom GPT mới cho từng job, upload design và yêu cầu `podhub_mockup_plan_v2`.
4. Plan phải chứa đúng số `mockup_prompts` cho từng sản phẩm đã chọn.
5. Extension lấy từng prompt, ghép với contract cố định và yêu cầu đúng một ảnh inline.
6. Mỗi ảnh được lưu backend với `product_id`, `mockup_no`, `asset_id` và `content_sha256`.
7. Backend chỉ xác nhận hoàn thành sản phẩm khi đủ N mockup number, N asset và N content hash duy nhất.
8. Sau khi một sản phẩm đủ ảnh, GPT trả một `podhub_product_listing_bundle_v2` chứa tất cả marketplace đã chọn cho sản phẩm đó.
9. Extension tách bundle thành từng listing record, lưu backend rồi chuyển sang sản phẩm tiếp theo.
10. Job chỉ chuyển `done` khi mọi sản phẩm và listing đều được backend xác nhận đầy đủ.

## UI

- Checkbox cho phép chọn nhiều sản phẩm, listing và job.
- Số mockup gợi ý của sản phẩm lấy từ `default_mockup_count` trong catalog backend.
- Nút trên cùng điều khiển Chạy, Tạm dừng an toàn và Tiếp tục.
- Upload thủ công hỗ trợ nhiều file và sử dụng cùng Queue với mọi nguồn khác.

## Cài thử

1. Mở `chrome://extensions`.
2. Bật Developer mode.
3. Chọn **Load unpacked**.
4. Chọn thư mục `Podhub-Mockup-GPTs` hoặc thư mục `release`.
5. Nhập license thuộc module `mockup-gpts`.

Backend phải có GPT link active, catalog sản phẩm và listing options cho module `mockup-gpts`. Extension không hard-code URL Custom GPT.

## Contract chính

- `POST /api/extension/mockup-jobs/manual`
- `GET /api/extension/mockup-jobs`
- `POST /api/extension/mockup-jobs/:id/mockups`
- `GET /api/extension/mockup-jobs/:id/products/:productId/validation`
- `POST /api/extension/mockup-jobs/:id/listings`
- `POST /api/extension/mockup-jobs/:id/status`

Chi tiết nằm trong `SERVER_CONTRACT.md` và `GPT_ACCEPTANCE_TESTS.md`.

Copy toàn bộ `Instructions_Podhub_Mockup_GPTs_v2.2.txt` vào **Configure → Instructions** của Custom GPT. Upload các file Knowledge `00`–`14`, `walmart-listing.md`, `etsy-listing.md` và `shopify-listing.md` vào phần Knowledge.
