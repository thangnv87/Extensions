'use strict';

const MODULE_ID = 'mockup-gpts';
const DEFAULT_ORIGIN = 'https://tools.podhub.space';
const $ = id => document.getElementById(id);

function setStatus(text, kind = '') {
  $('status').textContent = text;
  $('status').className = 'status ' + kind;
}

async function activate() {
  const licenseKey = $('license').value.trim();
  const origin = $('origin').value.trim().replace(/\/$/, '') || DEFAULT_ORIGIN;
  if (!licenseKey) return setStatus('Vui lòng nhập License Key.', 'error');
  setStatus('Đang kích hoạt…');
  await chrome.storage.local.set({pmg_api_origin: origin});
  const installationSaved = await chrome.storage.local.get('pmg_installation_id');
  const installationId = installationSaved.pmg_installation_id || crypto.randomUUID();
  await chrome.storage.local.set({pmg_installation_id: installationId});
  try {
    const response = await fetch(origin + '/api/extension/activate', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        license_key: licenseKey,
        installation_id: installationId,
        browser_name: navigator.userAgent.includes('Edg/') ? 'Edge' : 'Chrome',
        browser_version: navigator.userAgent,
        os: navigator.platform,
        extension_version: chrome.runtime.getManifest().version
      })
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.success) throw new Error(payload.error || 'Kích hoạt thất bại');
    const actualModule = payload.data?.module_id || payload.data?.routing?.module_id;
    if (actualModule && actualModule !== MODULE_ID) throw new Error(`License thuộc module ${actualModule}, không phải Mockup GPTs.`);
    await chrome.storage.local.set({
      pmg_license_token: payload.data.access_token,
      pmg_license_user: payload.data.user || null
    });
    await refreshConfig();
  } catch (error) {
    setStatus(error.message, 'error');
  }
}

async function refreshConfig() {
  setStatus('Đang lấy cấu hình từ backend…');
  const result = await chrome.runtime.sendMessage({type: 'PMG_API', request: {path: '/api/extension/config'}});
  if (!result?.ok) {
    $('open').disabled = true;
    return setStatus(result?.error || 'Không lấy được cấu hình.', 'error');
  }
  const data = result.data?.data || result.data || {};
  const link = data.gpt_links?.[MODULE_ID];
  if (!link?.url) {
    $('open').disabled = true;
    return setStatus('License hợp lệ, nhưng admin chưa cấu hình link Mockup GPTs.', 'error');
  }
  await chrome.storage.local.set({pmg_runtime_config: data, pmg_gpt_url: link.url});
  $('open').disabled = false;
  const user = (await chrome.storage.local.get('pmg_license_user')).pmg_license_user;
  setStatus(`Đã sẵn sàng${user?.username ? ` · ${user.username}` : ''}\nCấu hình v${data.pipeline?.version || 1}`, 'ok');
}

async function init() {
  const saved = await chrome.storage.local.get(['pmg_api_origin', 'pmg_license_token']);
  $('origin').value = saved.pmg_api_origin || DEFAULT_ORIGIN;
  if (saved.pmg_license_token) await refreshConfig();
}

$('activate').addEventListener('click', activate);
$('refresh').addEventListener('click', refreshConfig);
$('open').addEventListener('click', async () => {
  const saved = await chrome.storage.local.get('pmg_gpt_url');
  if (saved.pmg_gpt_url) chrome.runtime.sendMessage({type: 'PMG_OPEN_GPT', url: saved.pmg_gpt_url});
});
init();
