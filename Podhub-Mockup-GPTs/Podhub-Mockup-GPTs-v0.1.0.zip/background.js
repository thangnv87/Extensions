'use strict';

const DEFAULT_ORIGIN = 'https://tools.podhub.space';

function storageGet(keys) {
  return chrome.storage.local.get(keys);
}

async function apiRequest({path, method = 'GET', body, headers = {}}) {
  const saved = await storageGet(['pmg_api_origin', 'pmg_license_token']);
  const origin = String(saved.pmg_api_origin || DEFAULT_ORIGIN).replace(/\/$/, '');
  const token = String(saved.pmg_license_token || '');
  const response = await fetch(origin + path, {
    method,
    headers: {
      ...(body !== undefined ? {'Content-Type': 'application/json'} : {}),
      ...(token ? {Authorization: 'Bearer ' + token} : {}),
      ...headers
    },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || `HTTP ${response.status}`);
  return payload;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'PMG_API') {
    apiRequest(message.request).then(
      data => sendResponse({ok: true, data}),
      error => sendResponse({ok: false, error: error.message})
    );
    return true;
  }
  if (message?.type === 'PMG_OPEN_GPT') {
    chrome.tabs.create({url: message.url}).then(tab => sendResponse({ok: true, tabId: tab.id}));
    return true;
  }
  return false;
});
