# Podhub Mockup GPTs

Chrome Extension (Manifest V3) điều phối workflow:

1. Nhận một Raw Design đã duyệt.
2. Lấy link Custom GPT, pipeline và catalog sản phẩm từ Tools backend.
3. Cho người dùng chọn sản phẩm, số mockup, tỷ lệ ảnh và marketplace listing.
4. Gửi prompt có `job_id`, `task_id`, `design_id` đến ChatGPT.
5. Thu từng ảnh mockup và từng Listing JSON theo checkpoint.
6. Gửi kết quả về backend; nếu endpoint chưa sẵn sàng, tải ảnh backup về máy và giữ checkpoint nhẹ trong Chrome Storage.

## Nạp extension để thử

1. Mở `chrome://extensions`.
2. Bật Developer mode.
3. Chọn **Load unpacked**.
4. Chọn thư mục `Podhub-Mockup-GPTs`.
5. Bấm biểu tượng extension, nhập license thuộc module `mockup-gpts`.

Backend cần có GPT link active cho module `mockup-gpts`. Extension không hard-code URL Custom GPT.

## Backend endpoints

Các endpoint license/config hiện có được tái sử dụng:

- `POST /api/extension/activate`
- `GET /api/extension/config`

Hai endpoint mới dành cho kết quả:

- `POST /api/mockup-gpts/jobs/:job_id/mockups`
- `POST /api/mockup-gpts/jobs/:job_id/listings`

Chi tiết payload nằm trong `SERVER_CONTRACT.md`.

## Trạng thái hiện tại

Phiên bản `0.1.0` là vertical slice đầu tiên. Extension đã có UI, license/config động, catalog fallback, prompt runner, checkpoint, bắt ảnh và bắt JSON. Backend Mockup GPTs chưa được triển khai nên kết quả sẽ mang trạng thái `pending_backend` cho đến khi hai endpoint mới tồn tại.
