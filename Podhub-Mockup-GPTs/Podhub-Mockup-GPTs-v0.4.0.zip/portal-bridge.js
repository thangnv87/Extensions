(() => {
  'use strict';
  if (window.__podhubMockupPortalBridge) return;
  window.__podhubMockupPortalBridge = true;
  window.addEventListener('message', event => {
    const message=event.data;
    if(event.source!==window||event.origin!==location.origin||message?.type!=='PMG_PORTAL_IMPORT')return;
    chrome.runtime.sendMessage({type:'PMG_IMPORT_ASSET',asset:message.asset}).then(result=>{
      window.postMessage({type:'PMG_PORTAL_RESULT',request_id:message.request_id,ok:result?.ok===true,error:result?.error||null},location.origin);
    }).catch(error=>window.postMessage({type:'PMG_PORTAL_RESULT',request_id:message.request_id,ok:false,error:error.message},location.origin));
  });
})();
