# Podhub Mockup GPTs — Acceptance Tests

## Test 1: Planning handshake

Upload one design, then send:

```text
Use the uploaded approved design for mug_11oz and tumbler_20oz.

Analyze the supplied approved raw design and prepare mockups only for these selected products: mug_11oz, tumbler_20oz.
Create 2 mockups per product, aspect ratio 1:1.
Requested listing JSON: etsy, shopify.

Return exactly one fenced JSON block using schema podhub_mockup_plan_v2. After the plan, wait.

PODHUB_CONTEXT
task_id: mtask_test_001
design_id: des_test_001
END_PODHUB_CONTEXT
```

Pass criteria:

- One JSON fence only.
- Exact task/design IDs.
- Both products, in order.
- No generated image.

## Test 2: Single-image invariant

```text
Create mockup 1/2 for product mug_11oz. Generate exactly one high-quality photorealistic product mockup at 1:1. Preserve the supplied artwork, text, spelling and colors. Do not create a different product and do not add extra artwork.

PODHUB_CONTEXT
task_id: mtask_test_001
design_id: des_test_001
product_id: mug_11oz
mockup_no: 1
END_PODHUB_CONTEXT
```

Pass criteria: exactly one new mug image; no collage and no JSON.

## Test 3: Multi-product continuation

Repeat Test 2 for mug `2/2`, then tumbler `1/2` and `2/2`.

Pass criteria: one image per command and correct product every time.

## Test 4: Listing bundle after each product

```text
All two mug mockups are complete. Create one listing bundle for product mug_11oz and marketplaces etsy, shopify. Return schema_version podhub_product_listing_bundle_v2 with a listings array. Do not include tumbler.

PODHUB_CONTEXT
task_id: mtask_test_001
design_id: des_test_001
product_id: mug_11oz
END_PODHUB_CONTEXT
```

Pass criteria:

- One fenced bundle containing exactly mug×Etsy and mug×Shopify.
- No tumbler listing in this response.
- The Etsy listing has exactly 13 tags.
- Exact IDs and mockup numbers `[1,2]`.

Repeat after completing tumbler mockups. The second response must contain only tumbler×Etsy and tumbler×Shopify.
