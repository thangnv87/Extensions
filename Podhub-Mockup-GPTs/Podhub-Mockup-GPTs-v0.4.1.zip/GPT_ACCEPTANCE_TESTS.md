# Podhub Mockup GPTs — Acceptance Tests

## Test 1: Planning handshake

Upload one design, then send:

```text
PODHUB MOCKUP WORKFLOW
PODHUB_TASK: mtask_test_001
DESIGN_ID: des_test_001

Analyze the supplied approved raw design and prepare mockups only for these selected products: mug_11oz, tumbler_20oz.
Create 2 mockups per product, aspect ratio 1:1.
Requested listing JSON: etsy, shopify.

Return exactly one fenced JSON block using schema podhub_mockup_plan_v1. After the plan, wait.
```

Pass criteria:

- One JSON fence only.
- Exact task/design IDs.
- Both products, in order.
- No generated image.

## Test 2: Single-image invariant

```text
PODHUB_TASK: mtask_test_001
DESIGN_ID: des_test_001
Create mockup 1/2 for product mug_11oz. Generate exactly one high-quality photorealistic product mockup at 1:1. Preserve the supplied artwork, text, spelling and colors. Do not create a different product and do not add extra artwork.
```

Pass criteria: exactly one new mug image; no collage and no JSON.

## Test 3: Multi-product continuation

Repeat Test 2 for mug `2/2`, then tumbler `1/2` and `2/2`.

Pass criteria: one image per command and correct product every time.

## Test 4: Cartesian listing output

```text
PODHUB_TASK: mtask_test_001
DESIGN_ID: des_test_001
All requested mockups are complete. Create listing data for marketplaces: etsy, shopify. Return one fenced JSON object per design-product-marketplace using schema_version podhub_product_listing_v1. Include job_id, task_id, design_id, product_id, marketplace, title, description, tags, materials and mockup numbers. Do not invent price, SKU, inventory, brand, shipping or fulfillment data.
```

Pass criteria:

- Four separate fenced objects: mug×Etsy, mug×Shopify, tumbler×Etsy, tumbler×Shopify.
- No JSON array.
- Etsy objects have exactly 13 tags.
- Exact IDs and mockup numbers `[1,2]`.

