# Mockup GPTs Server Contract v1

## Module

```txt
module_id = mockup-gpts
```

`GET /api/extension/config` phải trả GPT link bằng key `mockup-gpts` và pipeline/catalog áp dụng cho license hiện tại.

## Mockup asset

```http
POST /api/mockup-gpts/jobs/:job_id/mockups
Authorization: Bearer <extension token>
Content-Type: application/json
```

```json
{
  "schema_version": "podhub_mockup_asset_v1",
  "job_id": "mjob_xxx",
  "task_id": "mtask_xxx",
  "design_id": "des_xxx",
  "product_id": "tumbler_20oz",
  "mockup_no": 1,
  "image_url": "temporary ChatGPT URL",
  "image_data_url": "data:image/png;base64,...",
  "filename": "des_xxx__tumbler_20oz__mockup_01.png",
  "captured_at": "ISO-8601"
}
```

Idempotency key:

```txt
user_id + design_id + product_id + mockup_no
```

Chỉ tính usage sau khi ảnh được lưu CDN/database thành công.

## Listing

```http
POST /api/mockup-gpts/jobs/:job_id/listings
Authorization: Bearer <extension token>
Content-Type: application/json
```

```json
{
  "schema_version": "podhub_product_listing_v1",
  "job_id": "mjob_xxx",
  "task_id": "mtask_xxx",
  "design_id": "des_xxx",
  "product_id": "tumbler_20oz",
  "marketplace": "etsy",
  "title": "...",
  "description": "...",
  "tags": [],
  "materials": [],
  "mockup_numbers": [1, 2, 3]
}
```

Idempotency key:

```txt
user_id + design_id + product_id + marketplace
```

Backend phải validate ownership của design/job, schema marketplace và mockup thuộc cùng design trước khi lưu.
