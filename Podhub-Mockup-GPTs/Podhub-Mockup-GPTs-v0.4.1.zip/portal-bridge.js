(() => {
  'use strict';
  if (window.__podhubMockupPortalBridge) return;
  window.__podhubMockupPortalBridge = true;
  const reply=(requestId,result={})=>window.postMessage({
    type:'PMG_PORTAL_RESULT',request_id:requestId,ok:result.ok===true,error:result.error||null
  },location.origin);
  window.addEventListener('message', event => {
    const message=event.data;
    if(event.source!==window||event.origin!==location.origin||message?.type!=='PMG_PORTAL_IMPORT')return;
    try{
      chrome.runtime.sendMessage({type:'PMG_IMPORT_ASSET',asset:message.asset},result=>{
        const runtimeError=chrome.runtime.lastError;
        if(runtimeError)return reply(message.request_id,{ok:false,error:runtimeError.message||'EXTENSION_BRIDGE_ERROR'});
        reply(message.request_id,result||{ok:false,error:'EXTENSION_NO_RESPONSE'});
      });
    }catch(error){reply(message.request_id,{ok:false,error:error?.message||'EXTENSION_BRIDGE_ERROR'})}
  });
})();
