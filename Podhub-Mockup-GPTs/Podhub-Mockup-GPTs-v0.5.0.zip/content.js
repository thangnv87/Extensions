(() => {
  'use strict';
  if (window.__podhubMockupGptsLoaded) return;
  window.__podhubMockupGptsLoaded = true;

  const MODULE_ID = 'mockup-gpts';
  const JOB_KEY = 'pmg_active_job';
  const FALLBACK_PRODUCTS = [
    {id:'tumbler_20oz', label:'20oz Tumbler', engine:'chatgpt'},
    {id:'mug_11oz', label:'11oz Mug', engine:'chatgpt'},
    {id:'blanket', label:'Blanket', engine:'chatgpt'},
    {id:'poster', label:'Poster', engine:'chatgpt'},
    {id:'tshirt', label:'T-shirt', engine:'auto'},
    {id:'hoodie', label:'Hoodie', engine:'auto'}
  ];
  let runtimeConfig = null;
  let activeJob = null;
  let observer = null;
  let knownImages = new Set();

  const storageGet = keys => chrome.storage.local.get(keys);
  const storageSet = value => chrome.storage.local.set(value);
  const api = async request => {
    const result = await chrome.runtime.sendMessage({type:'PMG_API', request});
    if (!result?.ok) throw new Error(result?.error || 'API request failed');
    return result.data?.data || result.data;
  };
  const safe = text => String(text || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const slug = text => String(text || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'').slice(0,80);

  function friendlyError(error) {
    const code = String(error?.message || error || '');
    if (code === 'EXTENSION_SESSION_INVALID') return 'Phiên extension không hợp lệ. Mở Cấu hình và kích hoạt lại License Key.';
    if (code === 'SESSION_KICKED') return 'Phiên extension đã bị thay thế hoặc thu hồi. Hãy kích hoạt lại License Key.';
    if (code === 'LICENSE_INACTIVE') return 'License Mockup GPTs đang bị khóa.';
    if (code === 'LICENSE_EXPIRED') return 'License Mockup GPTs đã hết hạn.';
    if (code.startsWith('LICENSE_MODULE_MISMATCH:')) return `License này thuộc module ${code.split(':')[1]}. Hãy nhập License Key của Mockup GPTs.`;
    return code || 'Có lỗi xảy ra.';
  }

  function status(text, kind = '', progress) {
    const box = document.querySelector('#pmg-status');
    if (!box) return;
    box.textContent = text;
    box.className = 'pmg-status ' + kind;
    if (kind === 'error' && /license|phiên extension/i.test(String(text))) document.querySelector('#pmg-config')?.classList.remove('hidden');
    const bar = document.querySelector('#pmg-progress i');
    if (bar && progress !== undefined) bar.style.width = Math.max(0, Math.min(100, progress)) + '%';
    if(kind==='ok')setTimeout(()=>{if(box.textContent===text){box.textContent='';box.className='pmg-status'}},2500);
  }

  function normalizeProducts(data) {
    const candidates = data?.product_catalog || data?.products || data?.pipeline?.products;
    if (!Array.isArray(candidates) || !candidates.length) return FALLBACK_PRODUCTS;
    return candidates.filter(x => x && x.enabled !== false).map(x => ({
      id:String(x.id || x.product_id || x.product_type),
      label:String(x.label || x.name || x.product_name || x.id),
      engine:String(x.engine || x.default_engine || 'chatgpt'),
      category:String(x.category || ''),
      image_url:String(x.image_url || x.thumbnail_url || ''),
      description:String(x.description || '')
    })).filter(x => x.id);
  }

  function renderProducts(products, selected = new Set()) {
    const hasRelevant=products.some(p=>selected.has(p.id));
    return products.map((p,index)=>`<label class="pmg-check"><input type="checkbox" name="pmg-product" value="${safe(p.id)}" ${selected.has(p.id)||(!hasRelevant&&index===0)?'checked':''}><span>${safe(p.label)}<small>${safe(p.engine)}</small></span></label>`).join('');
  }

  function normalizeListings(data){const rows=data?.listing_options;return(Array.isArray(rows)&&rows.length?rows:[{id:'etsy',label:'Etsy JSON'},{id:'walmart',label:'Walmart JSON'},{id:'shopify',label:'Shopify JSON'}]).filter(x=>x.enabled!==false).map(x=>({id:String(x.id||x.option_id),label:String(x.label||x.option_id)}))}
  function renderListings(rows,selected=new Set()){const hasRelevant=rows.some(x=>selected.has(x.id));return rows.map((x,i)=>`<label class="pmg-check"><input name="pmg-listing" type="checkbox" value="${safe(x.id)}" ${selected.has(x.id)||(!hasRelevant&&i===0)?'checked':''}><span>${safe(x.label)}</span></label>`).join('')}
  function bindProductCards(){}

  async function loadConfig() {
    const selectedProducts=new Set([...document.querySelectorAll('input[name="pmg-product"]:checked')].map(x=>x.value));
    const selectedListings=new Set([...document.querySelectorAll('input[name="pmg-listing"]:checked')].map(x=>x.value));
    runtimeConfig = await api({path:'/api/extension/config'});
    const actualModule=runtimeConfig?.module_id||runtimeConfig?.pipeline?.module_id;
    if(actualModule&&actualModule!==MODULE_ID)throw new Error(`License đang thuộc module ${actualModule}. Hãy dùng License Key Mockup GPTs.`);
    if(!Array.isArray(runtimeConfig?.product_catalog)||!Array.isArray(runtimeConfig?.listing_options))throw new Error('Backend không trả về catalog Mockup GPTs. Hãy kích hoạt đúng License Key của module Mockup GPTs.');
    const gptUrl = runtimeConfig?.gpt_links?.[MODULE_ID]?.url;
    if (!gptUrl) throw new Error('Admin chưa cấu hình link Mockup GPTs.');
    await storageSet({pmg_runtime_config:runtimeConfig, pmg_gpt_url:gptUrl});
    const grid = document.querySelector('#pmg-products');
    if (grid) { grid.innerHTML = renderProducts(normalizeProducts(runtimeConfig),selectedProducts); bindProductCards(); }
    const listings=document.querySelector('#pmg-listings');if(listings)listings.innerHTML=renderListings(normalizeListings(runtimeConfig),selectedListings);
    const badge=document.querySelector('#pmg-version');if(badge)badge.textContent=`Catalog v${runtimeConfig.catalog_version||1} · ${new Date().toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'})}`;
    renderAnnouncement(runtimeConfig.announcement);
    return runtimeConfig;
  }

  function renderAnnouncement(item){const box=document.querySelector('#pmg-announcement');if(!box)return;const visible=item?.enabled===true&&String(item.message||'').trim();box.hidden=!visible;box.className=`pmg-announcement ${safe(item?.tone||'info')}`;box.querySelector('span').textContent=visible?String(item.message).trim():''}

  function injectPanel() {
    if (document.querySelector('#pmg-root')) return;
    const root = document.createElement('aside');
    root.id = 'pmg-root';
    root.innerHTML=`<header class="pmg-head"><div><div class="pmg-title">Podhub Mockup GPTs</div><div class="pmg-sub">AI Product Studio · v${chrome.runtime.getManifest().version}</div></div><div class="pmg-head-actions"><button id="pmg-settings">⚙</button><button id="pmg-sync">↻</button><button id="pmg-close">×</button></div></header>
      <div id="pmg-announcement" class="pmg-announcement" hidden><b>📣</b><span></span></div><div id="pmg-status" class="pmg-status"></div><div class="pmg-actions pmg-actions-top"><button id="pmg-start" class="pmg-btn">Tạo workflow</button><button id="pmg-resume" class="pmg-btn pmg-secondary">Tiếp tục</button></div><div id="pmg-progress" class="pmg-progress"><i></i></div>
      <section id="pmg-config" class="pmg-config hidden"><div class="pmg-config-title"><b>Cấu hình</b><small id="pmg-version">Catalog v1</small></div><div class="pmg-license-row"><input id="pmg-license" type="password" placeholder="phb_ext_live_..."><button id="pmg-activate">KÍCH HOẠT</button></div><div class="pmg-config-grid"><label>Mockup / sản phẩm<input id="pmg-count" type="number" min="1" max="8" value="3"></label><label>Tỷ lệ<select id="pmg-ratio"><option>1:1</option><option>4:5</option><option>3:4</option><option>16:9</option></select></label></div><div class="pmg-config-section"><b>Sản phẩm mockup <small>· chọn nhiều</small></b><div id="pmg-products" class="pmg-products">${renderProducts(FALLBACK_PRODUCTS)}</div></div><div class="pmg-config-section"><b>Listing JSON <small>· chọn nhiều</small></b><div id="pmg-listings" class="pmg-option-grid">${renderListings(normalizeListings(null))}</div></div><label class="pmg-inline"><input id="pmg-auto" type="checkbox"> Tự chạy từng mockup</label></section>
      <nav class="pmg-tabs"><button class="active" data-page="products">Upload thủ công</button><button data-page="jobs">Job hiện tại</button><button data-page="history">Lịch sử</button></nav>
      <main class="pmg-main"><section class="pmg-page active" data-page="products"><div class="pmg-upload"><span>Chọn design từ máy</span><input id="pmg-file" type="file" accept="image/png,image/jpeg,image/webp" hidden><button id="pmg-upload-button" type="button">Upload</button><small id="pmg-design-note">Chưa chọn file</small></div><div class="pmg-empty">Chọn sản phẩm và sàn listing trong phần Cấu hình ⚙</div></section><section class="pmg-page" data-page="jobs"><div id="pmg-job-summary" class="pmg-empty">Chưa có job đang chạy.</div></section><section class="pmg-page" data-page="history"><div class="pmg-empty">Job hoàn tất sẽ được lưu về kho Podhub.</div></section></main><div class="pmg-log"><b>LOG</b><div>Mockup GPTs sẵn sàng.</div></div>`;
    document.body.appendChild(root);
    const launcher=document.createElement('button');launcher.id='pmg-launcher';launcher.textContent='M';launcher.title='Podhub Mockup GPTs';document.body.appendChild(launcher);
    const setActive=active=>{document.documentElement.setAttribute('data-podhub-active-panel',active?'mockup':'');document.dispatchEvent(new Event('podhub-panel-switch'))};
    const syncPanel=()=>{const active=document.documentElement.getAttribute('data-podhub-active-panel');root.style.display=active==='mockup'?'flex':'none';launcher.classList.toggle('active',active==='mockup');if(active==='mockup')loadConfig().catch(()=>{})};
    launcher.onclick=()=>setActive(document.documentElement.getAttribute('data-podhub-active-panel')!=='mockup');document.addEventListener('podhub-panel-switch',syncPanel);root.querySelector('#pmg-close').onclick=()=>setActive(false);syncPanel();
    root.querySelector('#pmg-settings').onclick=()=>root.querySelector('#pmg-config').classList.toggle('hidden');
    root.querySelector('#pmg-sync').onclick=()=>loadConfig().then(()=>status('Đã đồng bộ catalog.','ok')).catch(e=>status(friendlyError(e),'error'));
    root.querySelector('#pmg-activate').onclick=activateLicense;
    root.querySelectorAll('.pmg-tabs button').forEach(button=>button.onclick=()=>{root.querySelectorAll('.pmg-tabs button,.pmg-page').forEach(x=>x.classList.remove('active'));button.classList.add('active');root.querySelector(`.pmg-page[data-page="${button.dataset.page}"]`)?.classList.add('active')});
    root.querySelector('#pmg-start').onclick = startWorkflow;
    root.querySelector('#pmg-resume').onclick = resumeWorkflow;
    root.querySelector('#pmg-upload-button').onclick=()=>root.querySelector('#pmg-file').click();
    root.querySelector('#pmg-file').onchange = event => {
      const file = event.target.files?.[0];
      root.querySelector('#pmg-design-note').textContent = file ? `${file.name} · ${(file.size/1024/1024).toFixed(1)} MB` : 'Chưa chọn file';
    };
    loadConfig().then(() => status('Cấu hình đã sẵn sàng.', 'ok')).catch(error => status(friendlyError(error), 'error'));
    bindProductCards();setInterval(()=>{if(root.style.display!=='none')loadConfig().catch(()=>{})},60000);restoreJob();importPendingAsset().catch(error=>status(friendlyError(error),'error'));setInterval(()=>{if(!document.querySelector('#pmg-file')?.files?.length)importPendingAsset().catch(()=>{})},8000);
  }

  async function activateLicense(){
    try{const key=document.querySelector('#pmg-license')?.value.trim();if(!key)throw new Error('Vui lòng nhập License Key.');const saved=await storageGet(['pmg_installation_id']);const installationId=saved.pmg_installation_id||crypto.randomUUID();const result=await api({path:'/api/extension/activate',method:'POST',body:{license_key:key,installation_id:installationId,module_id:MODULE_ID,device_name:navigator.platform||'Chrome',extension_version:chrome.runtime.getManifest().version}});if(result.module_id&&result.module_id!==MODULE_ID)throw new Error(`License thuộc module ${result.module_id}, không phải Mockup GPTs.`);const token=result.token||result.access_token;if(!token)throw new Error('Kích hoạt không trả về phiên đăng nhập.');await storageSet({pmg_installation_id:installationId,pmg_license_token:token,pmg_license_user:result.user||null});await loadConfig();status('Đã kích hoạt License Key.','ok')}catch(error){status(friendlyError(error),'error')}
  }

  async function importPendingAsset(){
    const result=await chrome.runtime.sendMessage({type:'PMG_GET_PENDING_ASSET'});
    if(!result?.ok)throw new Error(result?.error||'Không tải được Raw Design từ Podhub.');
    const asset=result.data;if(!asset?.data_url)return false;
    const blob=await(await fetch(asset.data_url)).blob();
    const file=new File([blob],asset.name||'raw-design.png',{type:asset.type||blob.type||'image/png'});
    const transfer=new DataTransfer();transfer.items.add(file);
    const input=document.querySelector('#pmg-file');input.files=transfer.files;input.dispatchEvent(new Event('change',{bubbles:true}));
    document.documentElement.setAttribute('data-podhub-active-panel','mockup');document.dispatchEvent(new Event('podhub-panel-switch'));
    status(`Đã nhận ${file.name} từ Podhub Library. Chọn cấu hình rồi bấm Tạo workflow.`,'ok');
    return true;
  }

  function selectedOptions() {
    const products = [...document.querySelectorAll('input[name="pmg-product"]:checked')].map(x => x.value);
    const marketplaces = [...document.querySelectorAll('input[name="pmg-listing"]:checked')].map(x=>x.value);
    return {
      products,
      marketplaces,
      mockup_count:Math.max(1, Math.min(8, Number(document.querySelector('#pmg-count')?.value || 3))),
      aspect_ratio:document.querySelector('#pmg-ratio')?.value || '1:1',
      auto_run:document.querySelector('#pmg-auto')?.checked === true
    };
  }

  async function startWorkflow() {
    try {
      const file = document.querySelector('#pmg-file')?.files?.[0];
      if (!file) throw new Error('Vui lòng Upload thủ công một file design.');
      const options = selectedOptions();
      if (!options.products.length) throw new Error('Vui lòng chọn ít nhất một sản phẩm.');
      const designId = 'des_local_' + Date.now().toString(36);
      activeJob = {
        schema_version:'podhub_mockup_job_v1',
        job_id:'mjob_' + crypto.randomUUID(),
        task_id:'mtask_' + crypto.randomUUID(),
        design_id:designId,
        asset_id:null,
        design_name:file.name,
        design_file:{name:file.name, type:file.type, size:file.size},
        options,
        status:'draft',
        created_at:new Date().toISOString(),
        chat_url:location.href,
        captured_images:[],
        listing_results:[]
      };
      await saveJob();
      status('Đã lưu draft. Đang kiểm tra license và cấu hình…', '', 3);
      await loadConfig();
      markKnownImages();
      await attachDesignFile(file);
      const sent = await sendPrompt(buildPlanningPrompt(activeJob));
      if (!sent) throw new Error('Không tìm thấy ô nhập ChatGPT. Hãy mở đúng trang Custom GPT.');
      activeJob.status = 'planning';
      await saveJob();
      observeResults();
      status('Đã gửi yêu cầu lập kế hoạch. Đang chờ GPT…', 'ok', 8);
    } catch (error) { status(friendlyError(error), 'error'); }
  }

  function buildPlanningPrompt(job) {
    const p = runtimeConfig?.pipeline || {};
    const custom = String(p.analysis_prompt || '').trim();
    return `${custom ? custom + '\n\n' : ''}PODHUB MOCKUP WORKFLOW\nPODHUB_TASK: ${job.task_id}\nDESIGN_ID: ${job.design_id}\n\nAnalyze the supplied approved raw design and prepare mockups only for these selected products: ${job.options.products.join(', ')}.\nCreate ${job.options.mockup_count} mockups per product, aspect ratio ${job.options.aspect_ratio}.\nRequested listing JSON: ${job.options.marketplaces.join(', ') || 'none'}.\n\nRules:\n1. The user's selected products are authoritative. Do not add other products.\n2. Preserve the supplied artwork, typography, spelling and colors as accurately as possible.\n3. Work on one product and one mockup at a time.\n4. Before generating images, return exactly one fenced JSON block using schema podhub_mockup_plan_v1.\n5. Include design_id, task_id, product plan, mockup types and artwork risks.\n6. After the plan, wait for the next instruction.`;
  }

  async function attachDesignFile(file) {
    const input = [...document.querySelectorAll('input[type="file"]')].find(x => !x.closest('#pmg-root'));
    if (!input) return false;
    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    input.dispatchEvent(new Event('change', {bubbles:true}));
    await new Promise(resolve => setTimeout(resolve, 900));
    return true;
  }

  function composer() {
    return document.querySelector('#prompt-textarea') || document.querySelector('div[contenteditable="true"][data-lexical-editor="true"]') || document.querySelector('textarea');
  }

  async function sendPrompt(text) {
    const box = composer();
    if (!box) return false;
    box.focus();
    if (box.tagName === 'TEXTAREA') {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
      setter ? setter.call(box, text) : (box.value = text);
      box.dispatchEvent(new Event('input', {bubbles:true}));
    } else {
      box.textContent = text;
      box.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data:text}));
    }
    await new Promise(resolve => setTimeout(resolve, 250));
    const send = document.querySelector('[data-testid="send-button"]') || document.querySelector('button[aria-label*="Send"]') || document.querySelector('button[aria-label*="Gửi"]');
    if (send && !send.disabled) send.click();
    else box.dispatchEvent(new KeyboardEvent('keydown', {key:'Enter', code:'Enter', bubbles:true}));
    return true;
  }

  function markKnownImages() {
    knownImages = new Set([...document.images].map(imageIdentity).filter(Boolean));
  }

  function imageIdentity(img) {
    return img.currentSrc || img.src || '';
  }

  function observeResults() {
    observer?.disconnect();
    observer = new MutationObserver(() => scanResults());
    observer.observe(document.body, {childList:true, subtree:true});
    scanResults();
  }

  async function scanResults() {
    if (!activeJob) return;
    const blocks = [...document.querySelectorAll('pre code')];
    for (const block of blocks) {
      const text = block.textContent.trim();
      if (!text.includes('podhub_')) continue;
      let parsed;
      try { parsed = JSON.parse(text); } catch { continue; }
      if (parsed.design_id && parsed.design_id !== activeJob.design_id) continue;
      if (parsed.schema_version === 'podhub_mockup_plan_v1' && !activeJob.plan) {
        activeJob.plan = parsed;
        activeJob.status = 'plan_ready';
        await saveJob();
        status('Đã nhận mockup plan. Có thể tiếp tục tạo ảnh.', 'ok', 18);
        if (activeJob.options.auto_run) await requestNextMockup();
      }
      if (/podhub_.*listing/i.test(parsed.schema_version || '')) await captureListing(parsed);
    }
    for (const img of [...document.images]) {
      const id = imageIdentity(img);
      if (!id || knownImages.has(id) || img.closest('#pmg-root') || img.naturalWidth < 512 || img.naturalHeight < 512) continue;
      knownImages.add(id);
      await captureImage(img).catch(error => status('Lưu mockup lỗi: ' + error.message, 'error'));
    }
  }

  function nextMockupSpec() {
    const done = activeJob.captured_images.length;
    const count = activeJob.options.mockup_count;
    const productIndex = Math.floor(done / count);
    if (productIndex >= activeJob.options.products.length) return null;
    return {product_id:activeJob.options.products[productIndex], mockup_no:(done % count) + 1, total:count};
  }

  async function requestNextMockup() {
    const spec = nextMockupSpec();
    if (!spec) return requestListing();
    activeJob.current_mockup = spec;
    activeJob.status = 'generating_mockup';
    await saveJob();
    await sendPrompt(`PODHUB_TASK: ${activeJob.task_id}\nDESIGN_ID: ${activeJob.design_id}\nCreate mockup ${spec.mockup_no}/${spec.total} for product ${spec.product_id}. Generate exactly one high-quality photorealistic product mockup at ${activeJob.options.aspect_ratio}. Preserve the supplied artwork, text, spelling and colors. Do not create a different product and do not add extra artwork.`);
    status(`Đang tạo ${spec.product_id} · ${spec.mockup_no}/${spec.total}…`, 'ok', 20 + Math.round(activeJob.captured_images.length / (activeJob.options.products.length * activeJob.options.mockup_count) * 60));
  }

  async function imageToDataUrl(img) {
    const response = await fetch(imageIdentity(img), {credentials:'include'});
    if (!response.ok) throw new Error(`Không tải được ảnh GPT: HTTP ${response.status}`);
    const blob = await response.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  async function captureImage(img) {
    const spec = activeJob.current_mockup || nextMockupSpec();
    if (!spec) return;
    const item = {
      schema_version:'podhub_mockup_asset_v1',
      job_id:activeJob.job_id,
      task_id:activeJob.task_id,
      design_id:activeJob.design_id,
      product_id:spec.product_id,
      mockup_no:spec.mockup_no,
      image_url:imageIdentity(img),
      image_data_url:await imageToDataUrl(img),
      filename:`${slug(activeJob.design_id)}__${slug(spec.product_id)}__mockup_${String(spec.mockup_no).padStart(2,'0')}.png`,
      captured_at:new Date().toISOString()
    };
    const duplicate = activeJob.captured_images.some(x => x.product_id === item.product_id && x.mockup_no === item.mockup_no);
    if (duplicate) return;
    activeJob.captured_images.push(item);
    activeJob.current_mockup = null;
    activeJob.status = 'mockup_captured';
    await saveJob();
    try {
      const saved = await api({path:`/api/mockup-gpts/jobs/${encodeURIComponent(activeJob.job_id)}/mockups`, method:'POST', body:item});
      item.asset_id = saved?.asset_id || saved?.id || null;
      item.upload_status = 'saved';
    } catch (error) {
      item.upload_status = 'pending_backend';
      item.upload_error = error.message;
      downloadBackup(item.image_data_url, item.filename);
    }
    // Không giữ base64 lớn trong chrome.storage; nếu backend lỗi đã tải backup về máy.
    item.image_data_url = null;
    await saveJob();
    status(`Đã lấy mockup ${item.product_id} · ${item.mockup_no}.`, 'ok');
    if (activeJob.options.auto_run) setTimeout(requestNextMockup, 900);
  }

  function downloadBackup(dataUrl, filename) {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  async function requestListing() {
    if (!activeJob.options.marketplaces.length) return finishJob();
    activeJob.status = 'generating_listing';
    await saveJob();
    await sendPrompt(`PODHUB_TASK: ${activeJob.task_id}\nDESIGN_ID: ${activeJob.design_id}\nAll requested mockups are complete. Create listing data for marketplaces: ${activeJob.options.marketplaces.join(', ')}. Return one fenced JSON object per design-product-marketplace using schema_version podhub_product_listing_v1. Include job_id, task_id, design_id, product_id, marketplace, title, description, tags, materials and mockup numbers. Do not invent price, SKU, inventory, brand, shipping or fulfillment data.`);
    status('Đang yêu cầu Listing JSON…', 'ok', 88);
  }

  async function captureListing(listing) {
    const key = `${listing.product_id || ''}:${listing.marketplace || ''}`;
    if (activeJob.listing_results.some(x => `${x.product_id || ''}:${x.marketplace || ''}` === key)) return;
    activeJob.listing_results.push(listing);
    try {
      await api({path:`/api/mockup-gpts/jobs/${encodeURIComponent(activeJob.job_id)}/listings`, method:'POST', body:listing});
      listing.upload_status = 'saved';
    } catch (error) {
      listing.upload_status = 'pending_backend';
      listing.upload_error = error.message;
    }
    await saveJob();
    const expected = activeJob.options.products.length * activeJob.options.marketplaces.length;
    status(`Đã nhận Listing JSON ${activeJob.listing_results.length}/${expected}.`, 'ok', 90 + Math.round(activeJob.listing_results.length/expected*10));
    if (activeJob.listing_results.length >= expected) finishJob();
  }

  async function finishJob() {
    activeJob.status = 'done';
    activeJob.completed_at = new Date().toISOString();
    await saveJob();
    status(`Hoàn tất · ${activeJob.captured_images.length} mockup · ${activeJob.listing_results.length} listing.`, 'ok', 100);
  }

  async function saveJob() {
    if (!activeJob) return;
    await storageSet({[JOB_KEY]:activeJob});
  }

  async function restoreJob() {
    const saved = await storageGet(JOB_KEY);
    if (!saved[JOB_KEY]) return;
    activeJob = saved[JOB_KEY];
    if (activeJob.status !== 'done') {
      status(`Có job chưa xong: ${activeJob.design_name || activeJob.design_id}\nTrạng thái: ${activeJob.status}`, '', 10);
      markKnownImages();
      observeResults();
    }
  }

  async function resumeWorkflow() {
    if (!activeJob) return status('Không có job để tiếp tục.', 'error');
    if (activeJob.status === 'draft') {
      try {
        const file = document.querySelector('#pmg-file')?.files?.[0];
        if (!file) throw new Error('Draft đã được giữ. Hãy chọn lại Raw Design rồi bấm Tiếp tục.');
        await loadConfig();
        markKnownImages();
        await attachDesignFile(file);
        await sendPrompt(buildPlanningPrompt(activeJob));
        activeJob.status = 'planning';
        await saveJob();
        observeResults();
        return status('Đã gửi lại workflow từ draft.', 'ok', 8);
      } catch (error) { return status(friendlyError(error), 'error'); }
    }
    if (activeJob.status === 'plan_ready' || activeJob.status === 'mockup_captured' || activeJob.status === 'generating_mockup') return requestNextMockup();
    if (activeJob.status === 'generating_listing') return requestListing();
    status(`Job đang ở trạng thái ${activeJob.status}.`, '');
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'PMG_IMPORT_JOB') return false;
    activeJob = {...message.job, schema_version:'podhub_mockup_job_v1', chat_url:location.href};
    saveJob().then(() => {
      status(`Đã nhận design ${activeJob.design_id} từ thư viện.`, 'ok');
      sendResponse({ok:true});
    });
    return true;
  });

  const boot = setInterval(() => {
    if (!document.body) return;
    clearInterval(boot);
    injectPanel();
  }, 400);
})();
